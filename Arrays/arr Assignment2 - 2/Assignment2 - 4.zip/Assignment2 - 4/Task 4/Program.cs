﻿static int FerrisWheel (int[] weights, int max_weight)
{
    int people = 0;
    for (int i = 0; i < weights.Length; i++)
    {
        if (weights[i] > max_weight)
        {
            people++;
        }
    }
    return people;
}