﻿static bool Slant(int[,] arr)
{
    int counter = arr.GetLength(0);
    for (int i = 0; i < arr.GetLength(0); i++)
    {
        if (arr[i, i] <= arr[i + 1, i + 1] && arr[i, counter] <= arr[i + 1, counter--])
            return false;
        counter--;
    }
    return true;
}